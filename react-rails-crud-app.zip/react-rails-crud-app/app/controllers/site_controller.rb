# frozen_string_literal: true

class SiteController < ApplicationController
  def index; end
end
