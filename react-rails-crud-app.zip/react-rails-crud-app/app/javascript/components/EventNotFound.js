import React from 'react';

const EventNotFound = () => <p>Event not found!</p>;

export default EventNotFound;
