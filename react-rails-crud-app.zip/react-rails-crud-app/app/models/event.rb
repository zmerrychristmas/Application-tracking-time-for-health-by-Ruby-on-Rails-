# frozen_string_literal: true

class Event < ApplicationRecord
end
